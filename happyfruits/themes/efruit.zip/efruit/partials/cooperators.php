<!--
<div class="flat" style="background: #fff;">
    <div class="press">
        <img alt="deliverynow" height="20" src="<?=get_theme_assets_url()?>img/logos/gray-now-logo.png" class="asset" />
        <img alt="grabfood" height="25" src="<?=get_theme_assets_url()?>img/logos/gray-grabfood-logo.png" class="asset" />
        <img alt="baemin" height="20" src="<?=get_theme_assets_url()?>img/logos/gray-baemin-logo.png" class="asset" />
    </div>
</div>
-->