<?php if(!empty($heading)):?>
<div class="flat">
    <div class="marketing">
        <div class="container">
            <h1 class="title" bind-translate="<?=$heading?>"><?=$heading?></h1>
        </div>
    </div>
</div>
<?php endif; ?>