<?php /*
                <div class="flat efruitjs">
                  <div class="marketing" style="background-color: #383838;">
                    <div class="container" style="padding: 30px 5px 0;">
                        <h4 class="title" style="color: #51bd36;">{{__('Bạn muốn cập nhật món mới và các ưu đãi hấp dẫn?')}}</h4>
                        <form action="" method="post" id="subscribe-form" name="subscribe-form">
                        	<label for="mce-EMAIL"></label>
                        	<input style="max-width: 100%; width: 220px;" type="email" value="" name="email" class="email required" id="email" placeholder="{{__('Nhập email của bạn tại đây')}}" />
                            <!-- real people should not fill this in and expect good things - do not remove this or risk form bot signups-->
                            <div style="position: absolute; left: -5000px;"><input type="text" name="<?php echo md5("subscribe to info@". DOMAIN_NAME . date("WY"));?>" tabindex="-1" value=""/></div>
                            <input style="border: none; color: #fff;" type="submit" value="{{__('Ðăng ký')}}" name="subscribe" id="subscribe" class="btn btn-success"/>
                            <input type="hidden" name="action" value="subscribe_email" />
                            <input type="hidden" name="language_code" value="{{settings.language}}" />
                        </form>
                        <div class="clearfix"></div>
                    </div>
                  </div>
                </div>
*/ ?>
 <?php /*
    <div role="dialog" tabindex="-1" class="modal fade in" id="modal-subscribe" aria-hidden="false">
		<div class="modal-dialog normal-dialog">
			<div class="modal-content">
				<div class="modal-header" >
    				<button style="margin: -10px -15px 0 0;" aria-hidden="true" data-dismiss="modal" class="close" type="button">×</button>
    				<h4 style="color: #51bd36;font-weight: bold;" class="modal-title">{{__('Bạn muốn cập nhật món mới và các ưu đãi hấp dẫn?')}}</h4>
				</div>
				<div class="modal-body">
                    <form action="" method="post" id="subscribe-form" name="subscribe-form">
                    	<label for="mce-EMAIL"></label>
                    	<input style="max-width: 100%; width: 250px;" type="email" value="" name="email" class="email required" id="email" placeholder="{{__('Nhập email của bạn tại đây')}}" />
                        <!-- real people should not fill this in and expect good things - do not remove this or risk form bot signups-->
                        <div style="position: absolute; left: -5000px;"><input type="text" name="<?php echo md5("subscribe to info@". DOMAIN_NAME . date("WY"));?>" tabindex="-1" value=""/></div>
                        <input style="background: #51bd36; color: #fff;" type="submit" value="{{__('Đăng ký')}}" name="subscribe" id="subscribe" class="btn btn-success"/>
                        <input type="hidden" name="action" value="subscribe_email" />
                        <input type="hidden" name="language_code" value="{{settings.language}}" />
                    </form>
                    <div class="clearfix"></div>
                </div>
			</div> <!-- / .modal-content -->
		</div> <!-- / .modal-dialog -->
	</div>
 */ ?>

    <div class="subscribe-frm efruitjs"><?php /*
        <div class="minimize">
            <div class="subscribe-icon"><i class="fa fa-envelope"></i></div>
            <div class="subscribe-text efruit-vi">Đồng hành cùng eFruit</div>
            <div class="subscribe-text efruit-en efruitjs">Subscribe to our newsletter</div>
        </div>
        <div class="maximize">
            <div class="frm-header"><span class="efruit-vi">Đồng hành cùng eFruit</span><span class="efruit-en efruitjs">Subscribe to our newsletter</span><div class="minimize-btn"></div></div>
            <form action="" method="post" id="subscribe-form" name="subscribe-form">
            	<p bind-translate="Đăng ký email để cập nhật những sản phẩm mới và những ưu đãi hấp dẫn nhất!">Đăng ký email để cập nhật những sản phẩm mới và những ưu đãi hấp dẫn nhất!</p>
            	<input style="max-width: 100%;" type="email" value="" name="email" class="email required" id="email" placeholder="{{__('Nhập email của bạn tại đây')}}" />
                <!-- real people should not fill this in and expect good things - do not remove this or risk form bot signups-->
                <div style="position: absolute; left: -5000px;"><input type="text" name="<?php echo md5("subscribe to info@". DOMAIN_NAME . date("WY"));?>" tabindex="-1" value=""/></div>
                <input style="border: none; color: #fff;" type="submit" value="{{__('Ðăng ký')}}" name="subscribe" id="subscribe" class="btn btn-success"/>
                <input type="hidden" name="action" value="subscribe_email" />
                <input type="hidden" name="language_code" value="{{settings.language}}" />
            </form>
        </div>  */ ?>
    </div>
