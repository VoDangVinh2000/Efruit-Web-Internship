<?php
    $settings = get_setting_options();
    $start_year = env('START_YEAR', 2013);
    $current_year = date('Y');
    $copy_right_year = $start_year != $current_year?$start_year. '-'. $current_year:$start_year;
?>
<div class="y-foot">
	<div class="wrapper">
		<div class="identity">
			<span class="site-name <?=strlen($settings['short_site_name'])>12?'small':(strlen($settings['short_site_name'])>8?'medium':'')?>"><?=get_setting('short_site_name')?></span>
            <span class="copyright">&copy; <span class="number"><?=$copy_right_year?></span> <?=get_setting('short_site_name')?></span><br />
			<a class="share-btn" target="_blank" href="javascript:window.location=%22http://www.facebook.com/sharer.php?u=%22+encodeURIComponent(document.location)+%22&#38;t=%22+encodeURIComponent(document.title)"><i class="fa fa-facebook"></i>&nbsp;&nbsp;&nbsp;<span bind-translate="Chia sẻ">Chia sẻ</span></a><br/><br/>
			<?php if (env('GOV_LINK')):?>
            <a target="_blank" href="<?=env('GOV_LINK')?>"><img loading="lazy" src="<?=get_theme_assets_url()?>img/dathongbao.png" style="width: 130px;height: auto;" /></a>
            <?php endif; ?>
		</div>
		<div class="column">
			<div class="group-1">
				<dl>
					<dt bind-translate="Về chúng tôi">Về chúng tôi</dt>
					<dd><a href="/vi/gioi-thieu" bind-translate="Giới thiệu">Giới thiệu</a></dd>
					<dd><a href="/vi/thu-vien-hinh-anh" bind-translate="Thư viện hình ảnh">Thư viện hình ảnh</a></dd>
					<dd><a href="/tuyen-dung" target="_blank" bind-translate="Tuyển dụng">Tuyển dụng</a></dd>
					<dd><a href="/vi/chinh-sach-quy-dinh-chung" bind-translate="Chính sách, quy định chung">Chính sách, quy định chung</a></dd>
					<dd><a href="/vi/chinh-sach-doi-tra" bind-translate="Chính sách đổi trả">Chính sách đổi trả</a></dd>
					<dd><a href="/vi/chinh-sach-bao-mat-thong-tin" bind-translate="Chính sách bảo mật thông tin">Chính sách bảo mật thông tin</a></dd>
				</dl>
			</div>
		</div>
		<div class="column questions">
			<div class="group-2">
				<dl>
					<dt bind-translate="Có thể bạn thắc mắc">Có thể bạn thắc mắc</dt>
					<dd><a href="/vi/san-pham" bind-translate="Sản phẩm">Sản phẩm</a></dd>
					<dd><a href="/vi/giao-hang" bind-translate="Phương thức giao hàng">Phương thức giao hàng</a></dd>
					<dd><a href="/vi/dat-hang" bind-translate="Phương thức đặt hàng">Phương thức đặt hàng</a></dd>
					<dd><a href="/vi/cam-ket-san-pham" bind-translate="Cam kết sản phẩm">Cam kết sản phẩm</a></dd>
					<dd><a href="/vi/uu-dai-thanh-vien" bind-translate="Ưu đãi thành viên">Ưu đãi thành viên</a></dd>
					<dd><a href="/vi/cau-hoi-khac" bind-translate="Câu hỏi khác">Câu hỏi khác</a></dd>
				</dl>
			</div>
		</div>
		<div class="column contact">
			<div class="group-3">
				<dl>
					<dt bind-translate="Liên hệ">Liên hệ</dt>
                    <dd><i class="fa fa-home"></i> <span bind-translate="Cửa hàng">Cửa hàng</span>: <span class="efruit-vi"><?=getvalue($main_branch, 'short_address')?></span><span class="efruit-en efruitjs"><?=getvalue($main_branch, 'en_address')?></span></dd>
                    <?php if(!empty($settings['company_address'])) :?>
                        <dd><i class="fa fa-home"></i> <span bind-translate="Công ty">Công ty</span>: <span><?=$settings['company_address']?></span></dd>
                    <?php endif; ?>
                    <dd><i class="fa fa-phone"></i> <span><?=getvalue($main_branch, 'phone_number', '0938.70.70.15 - 0906.70.70.15')?></span></dd>
					<dd><i class="fa fa-envelope"></i> <a id="info-email">Info email</a>&nbsp;&nbsp;<i class="fa fa-envelope-o"></i> <a id="cskh-email">CSKH</a></dd>
					<?php if(!empty($settings['facebook_link'])) :?>
					    <dd><i class="fa fa-facebook"></i>&nbsp;&nbsp;<a href="<?=$settings['facebook_link']?>" target="_blank"><?=$settings['facebook_link']?></a></dd>
                    <?php endif; ?>
				</dl>
			</div>
		</div>
		<div class="clearfix"></div>
	</div>
</div>
<?php if(!empty($settings['company_name']) && !empty($settings['company_address'])) :?>
<div class="footer-company-info">
	<span style="color: #999; clear: both; display: block;"><?=$settings['company_name']?>. ĐC: <?=$settings['company_address']?></span>
    <?php if(!empty($settings['company_info'])) :?>
        <span style="color: #999; clear: both; display: block;"><?=$settings['company_info']?></span>
    <?php endif; ?>
    <?php if(!empty($settings['company_extra_1'])) :?>
        <span style="color: #999; clear: both; display: block;"><?=$settings['company_extra_1']?></span>
    <?php endif; ?>
    <?php if(!empty($settings['company_extra_2'])) :?>
        <span style="color: #999; clear: both; display: block;"><?=$settings['company_extra_2']?></span>
    <?php endif; ?>
</div>
<?php endif; ?>